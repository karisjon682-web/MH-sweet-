import type { Metadata } from "next";
import { Phone, MapPin, Clock } from "lucide-react";
import { ContactForm } from "@/components/ContactForm";
import { GoogleMap } from "@/components/GoogleMap";
import { SHOP } from "@/lib/constants";

export const metadata: Metadata = {
  title: "Visit & Contact Us",
  description: "Find M H Sweet's two shops in Nakhtrana, call us, or send a message.",
};

export default function ContactPage() {
  return (
    <div className="container-shop py-10">
      <div className="mb-10">
        <span className="eyebrow">We&apos;d love to hear from you</span>
        <h1 className="mt-1 font-display text-3xl text-maroon dark:text-marigold sm:text-4xl">
          Visit &amp; Contact
        </h1>
      </div>

      <div className="grid gap-10 lg:grid-cols-2">
        <div className="flex flex-col gap-8">
          <div className="card-surface flex items-center gap-4 p-5">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-maroon/10 text-maroon dark:bg-marigold/15 dark:text-marigold">
              <Phone size={20} />
            </span>
            <div>
              <p className="font-body text-xs uppercase tracking-wide text-ink/50 dark:text-ivory/50">Call Us</p>
              <a href={`tel:${SHOP.phone.replace(/\s/g, "")}`} className="font-display text-lg text-ink dark:text-ivory">
                {SHOP.phone}
              </a>
            </div>
          </div>

          <div className="card-surface flex items-center gap-4 p-5">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-maroon/10 text-maroon dark:bg-marigold/15 dark:text-marigold">
              <Clock size={20} />
            </span>
            <div>
              <p className="font-body text-xs uppercase tracking-wide text-ink/50 dark:text-ivory/50">Hours</p>
              <p className="font-display text-lg text-ink dark:text-ivory">9:00 AM – 9:30 PM, Daily</p>
            </div>
          </div>

          {SHOP.locations.map((loc) => (
            <div key={loc.label} className="flex flex-col gap-3">
              <div className="flex items-start gap-3">
                <MapPin size={20} className="mt-0.5 shrink-0 text-maroon dark:text-marigold" />
                <div>
                  <p className="font-display text-lg text-ink dark:text-ivory">{loc.label}</p>
                  <p className="font-body text-sm text-ink/65 dark:text-ivory/65">{loc.address}</p>
                </div>
              </div>
              <GoogleMap src={loc.mapEmbed} title={`M H Sweet — ${loc.label}`} />
            </div>
          ))}
        </div>

        <div>
          <h2 className="mb-4 font-display text-xl text-ink dark:text-ivory">Send a Message</h2>
          <ContactForm />
        </div>
      </div>
    </div>
  );
}
