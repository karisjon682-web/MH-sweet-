import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Sparkles, Leaf, Truck } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { ProductGrid } from "@/components/products/ProductGrid";
import { SHOP, waLink } from "@/lib/constants";
import type { Product } from "@/lib/types";

export const revalidate = 60;

async function getFeaturedProducts(): Promise<Product[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("products")
    .select("*, categories(*)")
    .eq("is_featured", true)
    .eq("is_available", true)
    .limit(8);
  return (data as Product[]) ?? [];
}

export default async function HomePage() {
  const featured = await getFeaturedProducts();

  return (
    <div>
      {/* HERO */}
      <section className="relative overflow-hidden bg-maroon dark:bg-nightmaroon">
        <div
          aria-hidden
          className="absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage:
              "radial-gradient(circle, #E8A33D 1.5px, transparent 1.5px)",
            backgroundSize: "24px 24px",
          }}
        />
        <div className="container-shop relative grid gap-10 py-16 sm:py-24 md:grid-cols-2 md:items-center">
          <div>
            <span className="eyebrow text-marigold">Est. in Nakhtrana, Kutch</span>
            <h1 className="mt-3 font-display text-4xl leading-[1.1] text-ivory sm:text-5xl md:text-6xl">
              Sweetness that
              <span className="relative mx-3 inline-block text-marigold">
                lingers
                <svg
                  aria-hidden
                  viewBox="0 0 200 12"
                  className="absolute -bottom-2 left-0 w-full text-marigold"
                >
                  <path d="M2 8 Q 50 -2 100 6 T 198 5" stroke="currentColor" strokeWidth="3" fill="none" strokeLinecap="round" />
                </svg>
              </span>
              in every bite.
            </h1>
            <p className="mt-6 max-w-md font-body text-base leading-relaxed text-ivory/75">
              {SHOP.about}
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="/products" className="btn-primary bg-marigold text-ink hover:bg-marigold-light">
                Explore Our Menu <ArrowRight size={16} />
              </Link>
              <a
                href={waLink(`Hello ${SHOP.name}! I'd like to place an order.`)}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-whatsapp"
              >
                Order on WhatsApp
              </a>
            </div>
          </div>

          <div className="relative mx-auto flex h-64 w-64 items-center justify-center sm:h-80 sm:w-80">
            <div className="absolute inset-0 rounded-full bg-marigold/20 blur-2xl" />
            <div className="relative flex h-full w-full items-center justify-center rounded-full border-4 border-marigold/40 bg-maroon-dark/40">
              <span className="font-display text-7xl text-marigold">MH</span>
              <span
                aria-hidden
                className="absolute -top-4 left-1/2 h-10 w-1 -translate-x-1/2 rounded-full bg-marigold/60 animate-steam"
                style={{ animationDelay: "0s" }}
              />
              <span
                aria-hidden
                className="absolute -top-4 left-[42%] h-8 w-1 -translate-x-1/2 rounded-full bg-marigold/40 animate-steam"
                style={{ animationDelay: "0.6s" }}
              />
              <span
                aria-hidden
                className="absolute -top-4 left-[58%] h-8 w-1 -translate-x-1/2 rounded-full bg-marigold/40 animate-steam"
                style={{ animationDelay: "1.1s" }}
              />
            </div>
          </div>
        </div>
        <span className="thali-divider" aria-hidden />
      </section>

      {/* VALUE PROPS */}
      <section className="container-shop grid gap-6 py-14 sm:grid-cols-3">
        {[
          { icon: Sparkles, title: "Traditional Recipes", copy: "Family recipes passed down, made fresh every single day." },
          { icon: Leaf, title: "Premium Ingredients", copy: "Pure ghee, real mava, and hand-picked dry fruits — no shortcuts." },
          { icon: Truck, title: "Festival Ready", copy: "Bulk orders for weddings, festivals & celebrations, delivered on time." },
        ].map(({ icon: Icon, title, copy }) => (
          <div key={title} className="card-surface flex flex-col items-start gap-3 p-6">
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-marigold/15 text-marigold-dark dark:text-marigold">
              <Icon size={20} />
            </span>
            <h3 className="font-display text-lg text-ink dark:text-ivory">{title}</h3>
            <p className="font-body text-sm text-ink/65 dark:text-ivory/65">{copy}</p>
          </div>
        ))}
      </section>

      {/* FEATURED PRODUCTS */}
      {featured.length > 0 && (
        <section className="container-shop py-8">
          <div className="mb-8 flex items-end justify-between">
            <div>
              <span className="eyebrow">Customer Favourites</span>
              <h2 className="mt-1 font-display text-3xl text-maroon dark:text-marigold">Most Loved Sweets</h2>
            </div>
            <Link href="/products" className="hidden font-body text-sm font-semibold text-maroon hover:underline dark:text-marigold sm:block">
              View Full Menu →
            </Link>
          </div>
          <ProductGrid products={featured} />
          <div className="mt-8 text-center sm:hidden">
            <Link href="/products" className="btn-secondary">
              View Full Menu
            </Link>
          </div>
        </section>
      )}

      {/* CATEGORY BANNER */}
      <section className="container-shop grid gap-6 py-14 sm:grid-cols-2">
        <Link
          href="/products?type=sweets"
          className="group relative flex h-48 flex-col justify-end overflow-hidden rounded-2xl bg-maroon p-6 text-ivory"
        >
          <span className="eyebrow text-marigold">Mithai</span>
          <h3 className="font-display text-2xl">Pure Sweets</h3>
          <p className="font-body text-sm text-ivory/70">Mava, ghee, kaju & Bengali specials</p>
          <ArrowRight className="absolute right-6 top-6 text-marigold transition-transform group-hover:translate-x-1" />
        </Link>
        <Link
          href="/products?type=farsan"
          className="group relative flex h-48 flex-col justify-end overflow-hidden rounded-2xl bg-leaf p-6 text-ivory"
        >
          <span className="eyebrow text-ivory/80">Namkeen</span>
          <h3 className="font-display text-2xl">Crispy Farsan</h3>
          <p className="font-body text-sm text-ivory/70">Sev, gathiya, chavdo & more</p>
          <ArrowRight className="absolute right-6 top-6 transition-transform group-hover:translate-x-1" />
        </Link>
      </section>
    </div>
  );
}
