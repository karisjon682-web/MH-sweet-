import type { Metadata } from "next";
import { Suspense } from "react";
import { createClient } from "@/lib/supabase/server";
import { SearchFilter } from "@/components/products/SearchFilter";
import { ProductGrid } from "@/components/products/ProductGrid";
import type { Category, Product, ProductType } from "@/lib/types";

export const metadata: Metadata = {
  title: "Our Menu — Sweets & Farsan",
  description:
    "Browse our full range of traditional Indian sweets and crispy farsan, freshly made in Nakhtrana.",
};

export const revalidate = 60;

interface PageProps {
  searchParams: Promise<{ type?: string; category?: string; q?: string }>;
}

async function getCategories(): Promise<Category[]> {
  const supabase = await createClient();
  const { data } = await supabase.from("categories").select("*").order("sort_order");
  return (data as Category[]) ?? [];
}

async function getProducts(params: { type: ProductType; category?: string; q?: string }) {
  const supabase = await createClient();
  let query = supabase
    .from("products")
    .select("*, categories(*)")
    .eq("type", params.type)
    .order("is_featured", { ascending: false })
    .order("name");

  if (params.category) {
    const { data: cat } = await supabase
      .from("categories")
      .select("id")
      .eq("slug", params.category)
      .single();
    if (cat) query = query.eq("category_id", cat.id);
  }

  if (params.q) {
    query = query.ilike("name", `%${params.q}%`);
  }

  const { data } = await query;
  return (data as Product[]) ?? [];
}

export default async function ProductsPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const type: ProductType = params.type === "farsan" ? "farsan" : "sweets";

  const [categories, products] = await Promise.all([
    getCategories(),
    getProducts({ type, category: params.category, q: params.q }),
  ]);

  return (
    <div className="container-shop py-10">
      <div className="mb-8">
        <span className="eyebrow">Full Menu</span>
        <h1 className="mt-1 font-display text-3xl text-maroon dark:text-marigold sm:text-4xl">
          Sweets &amp; Farsan
        </h1>
        <p className="mt-2 max-w-xl font-body text-sm text-ink/65 dark:text-ivory/65">
          Every item is made fresh in-house with pure ghee and traditional recipes. Prices shown are per Kg unless noted.
        </p>
      </div>

      <div className="mb-8">
        <Suspense fallback={<div className="h-24" />}>
          <SearchFilter categories={categories} />
        </Suspense>
      </div>

      <ProductGrid products={products} />
    </div>
  );
}
