import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ChevronLeft } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { QuickOrderForm } from "@/components/products/QuickOrderForm";
import { ProductGrid } from "@/components/products/ProductGrid";
import { formatPrice } from "@/lib/utils";
import type { Product } from "@/lib/types";

export const revalidate = 60;

interface PageProps {
  params: Promise<{ slug: string }>;
}

async function getProduct(slug: string): Promise<Product | null> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("products")
    .select("*, categories(*)")
    .eq("slug", slug)
    .single();
  return (data as Product) ?? null;
}

async function getRelated(product: Product): Promise<Product[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("products")
    .select("*, categories(*)")
    .eq("type", product.type)
    .neq("id", product.id)
    .limit(4);
  return (data as Product[]) ?? [];
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProduct(slug);
  if (!product) return { title: "Product Not Found" };
  return {
    title: product.name,
    description: product.description || `${product.name} — ${formatPrice(product.price, product.unit)} at M H Sweet, Nakhtrana.`,
    openGraph: { images: product.image_url ? [product.image_url] : [] },
  };
}

export default async function ProductDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const product = await getProduct(slug);
  if (!product) notFound();

  const related = await getRelated(product);

  return (
    <div className="container-shop py-10">
      <Link href="/products" className="mb-6 inline-flex items-center gap-1 font-body text-sm font-medium text-maroon hover:underline dark:text-marigold">
        <ChevronLeft size={16} /> Back to Menu
      </Link>

      <div className="grid gap-10 md:grid-cols-2">
        <div className="relative aspect-square overflow-hidden rounded-2xl bg-marigold/10">
          {product.image_url ? (
            <Image src={product.image_url} alt={product.name} fill className="object-cover" priority />
          ) : (
            <div className="flex h-full w-full items-center justify-center font-display text-6xl text-marigold-dark/40">
              MH
            </div>
          )}
        </div>

        <div className="flex flex-col gap-5">
          {product.categories?.name && (
            <span className="eyebrow w-fit">{product.categories.name}</span>
          )}
          <h1 className="font-display text-3xl text-ink dark:text-ivory sm:text-4xl">{product.name}</h1>
          <p className="font-display text-2xl text-maroon dark:text-marigold">
            {formatPrice(product.price, product.unit)}
          </p>
          {product.description && (
            <p className="font-body text-sm leading-relaxed text-ink/70 dark:text-ivory/70">
              {product.description}
            </p>
          )}
          {!product.is_available && (
            <p className="w-fit rounded-full bg-red-100 px-4 py-1.5 font-body text-sm font-medium text-red-700">
              Currently unavailable
            </p>
          )}

          {product.is_available && <QuickOrderForm product={product} />}
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-16">
          <h2 className="mb-6 font-display text-2xl text-maroon dark:text-marigold">You may also like</h2>
          <ProductGrid products={related} />
        </section>
      )}
    </div>
  );
}
