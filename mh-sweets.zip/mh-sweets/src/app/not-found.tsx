import Link from "next/link";

export default function NotFound() {
  return (
    <div className="container-shop flex min-h-[60vh] flex-col items-center justify-center gap-4 py-20 text-center">
      <span className="font-display text-7xl text-marigold">404</span>
      <h1 className="font-display text-2xl text-maroon dark:text-marigold">This treat isn&apos;t on our shelf</h1>
      <p className="max-w-sm font-body text-sm text-ink/60 dark:text-ivory/60">
        The page you&apos;re looking for doesn&apos;t exist. Let&apos;s get you back to something sweet.
      </p>
      <Link href="/" className="btn-primary mt-2">
        Back to Home
      </Link>
    </div>
  );
}
