import { ImageResponse } from "next/og";
import { SHOP } from "@/lib/constants";

export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          background: "#7A1E2B",
          color: "#FBF3E7",
          fontFamily: "serif",
        }}
      >
        <div style={{ fontSize: 90, color: "#E8A33D", display: "flex" }}>{SHOP.name}</div>
        <div style={{ fontSize: 34, letterSpacing: 6, textTransform: "uppercase", color: "#F3C877", display: "flex", marginTop: 12 }}>
          {SHOP.tagline}
        </div>
      </div>
    ),
    size
  );
}
