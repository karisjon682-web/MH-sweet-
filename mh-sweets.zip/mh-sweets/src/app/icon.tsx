import { ImageResponse } from "next/og";

export const size = { width: 64, height: 64 };
export const contentType = "image/png";

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#7A1E2B",
          color: "#E8A33D",
          fontSize: 30,
          fontWeight: 700,
          borderRadius: "50%",
          fontFamily: "serif",
        }}
      >
        MH
      </div>
    ),
    size
  );
}
