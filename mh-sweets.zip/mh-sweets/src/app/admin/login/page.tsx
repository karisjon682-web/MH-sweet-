"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, LockKeyhole } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { SHOP } from "@/lib/constants";

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError("Invalid email or password.");
      return;
    }
    router.push("/admin/dashboard");
    router.refresh();
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="card-surface w-full max-w-sm p-8">
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-maroon text-ivory dark:bg-marigold dark:text-ink">
            <LockKeyhole size={20} />
          </span>
          <h1 className="font-display text-2xl text-maroon dark:text-marigold">{SHOP.name} Admin</h1>
          <p className="font-body text-sm text-ink/60 dark:text-ivory/60">Sign in to manage your shop</p>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label className="font-body text-sm font-medium">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="font-body text-sm font-medium">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
            />
          </div>
          {error && <p className="font-body text-sm text-red-600">{error}</p>}
          <button type="submit" disabled={loading} className="btn-primary mt-2 justify-center">
            {loading && <Loader2 className="animate-spin" size={16} />}
            Sign In
          </button>
        </form>
      </div>
    </div>
  );
}
