import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { ProductForm } from "@/components/products/ProductForm";
import type { Category, Product } from "@/lib/types";

interface PageProps {
  params: Promise<{ id: string }>;
}

export default async function EditProductPage({ params }: PageProps) {
  const { id } = await params;
  const supabase = await createClient();

  const [{ data: product }, { data: categoryData }] = await Promise.all([
    supabase.from("products").select("*").eq("id", id).single(),
    supabase.from("categories").select("*").order("sort_order"),
  ]);

  if (!product) notFound();
  const categories = (categoryData as Category[]) ?? [];

  return (
    <div>
      <h1 className="mb-6 font-display text-2xl text-maroon dark:text-marigold sm:text-3xl">Edit Product</h1>
      <div className="card-surface p-6 sm:p-8">
        <ProductForm product={product as Product} categories={categories} />
      </div>
    </div>
  );
}
