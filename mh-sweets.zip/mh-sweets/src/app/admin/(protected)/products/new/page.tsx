import { createClient } from "@/lib/supabase/server";
import { ProductForm } from "@/components/products/ProductForm";
import type { Category } from "@/lib/types";

export default async function NewProductPage() {
  const supabase = await createClient();
  const { data } = await supabase.from("categories").select("*").order("sort_order");
  const categories = (data as Category[]) ?? [];

  return (
    <div>
      <h1 className="mb-6 font-display text-2xl text-maroon dark:text-marigold sm:text-3xl">Add Product</h1>
      <div className="card-surface p-6 sm:p-8">
        <ProductForm categories={categories} />
      </div>
    </div>
  );
}
