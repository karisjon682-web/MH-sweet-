import Link from "next/link";
import Image from "next/image";
import { PlusCircle, Pencil } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { DeleteButton } from "@/components/admin/DeleteButton";
import { formatPrice } from "@/lib/utils";
import type { Product } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function AdminProductsPage() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("products")
    .select("*, categories(*)")
    .order("type")
    .order("name");
  const products = (data as Product[]) ?? [];

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-2xl text-maroon dark:text-marigold sm:text-3xl">Products</h1>
        <Link href="/admin/products/new" className="btn-primary">
          <PlusCircle size={16} /> Add Product
        </Link>
      </div>

      <div className="card-surface overflow-x-auto">
        <table className="w-full min-w-[640px] text-left font-body text-sm">
          <thead className="border-b border-maroon/10 text-xs uppercase tracking-wide text-ink/50 dark:border-ivory/10 dark:text-ivory/50">
            <tr>
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">Type</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} className="border-b border-maroon/5 last:border-0 dark:border-ivory/5">
                <td className="flex items-center gap-3 px-4 py-3">
                  <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-lg bg-marigold/10">
                    {p.image_url && <Image src={p.image_url} alt={p.name} fill className="object-cover" />}
                  </div>
                  <span className="font-medium">{p.name}</span>
                  {p.is_featured && <span className="rounded-full bg-marigold/20 px-2 py-0.5 text-[10px] font-semibold text-marigold-dark">Featured</span>}
                </td>
                <td className="px-4 py-3 capitalize">{p.type}</td>
                <td className="px-4 py-3">{p.categories?.name ?? "—"}</td>
                <td className="px-4 py-3">{formatPrice(p.price, p.unit)}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${p.is_available ? "bg-leaf/15 text-leaf" : "bg-red-100 text-red-600"}`}>
                    {p.is_available ? "Available" : "Unavailable"}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-1">
                    <Link href={`/admin/products/${p.id}/edit`} className="flex h-9 w-9 items-center justify-center rounded-lg text-maroon transition-colors hover:bg-maroon/5 dark:text-marigold dark:hover:bg-ivory/10">
                      <Pencil size={16} />
                    </Link>
                    <DeleteButton table="products" id={p.id} confirmLabel={`Delete "${p.name}"?`} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {products.length === 0 && (
          <p className="p-8 text-center font-body text-sm text-ink/50 dark:text-ivory/50">No products yet. Add your first one!</p>
        )}
      </div>
    </div>
  );
}
