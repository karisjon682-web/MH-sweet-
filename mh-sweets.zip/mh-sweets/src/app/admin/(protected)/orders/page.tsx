import { createClient } from "@/lib/supabase/server";
import { StatusSelect } from "@/components/admin/StatusSelect";
import { formatPrice } from "@/lib/utils";
import type { Order } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function AdminOrdersPage() {
  const supabase = await createClient();
  const { data } = await supabase.from("orders").select("*").order("created_at", { ascending: false });
  const orders = (data as Order[]) ?? [];

  return (
    <div>
      <h1 className="mb-6 font-display text-2xl text-maroon dark:text-marigold sm:text-3xl">Orders</h1>

      <div className="card-surface overflow-x-auto">
        <table className="w-full min-w-[720px] text-left font-body text-sm">
          <thead className="border-b border-maroon/10 text-xs uppercase tracking-wide text-ink/50 dark:border-ivory/10 dark:text-ivory/50">
            <tr>
              <th className="px-4 py-3">Customer</th>
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">Qty</th>
              <th className="px-4 py-3">Note</th>
              <th className="px-4 py-3">Received</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id} className="border-b border-maroon/5 last:border-0 dark:border-ivory/5">
                <td className="px-4 py-3">
                  <p className="font-medium">{o.customer_name}</p>
                  <a href={`tel:${o.phone}`} className="text-xs text-maroon dark:text-marigold">{o.phone}</a>
                </td>
                <td className="px-4 py-3">{o.product_name}</td>
                <td className="px-4 py-3">{o.quantity} {o.unit}</td>
                <td className="max-w-[200px] truncate px-4 py-3 text-ink/60 dark:text-ivory/60">{o.note || "—"}</td>
                <td className="px-4 py-3 text-xs text-ink/50 dark:text-ivory/50">
                  {new Date(o.created_at).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}
                </td>
                <td className="px-4 py-3">
                  <StatusSelect table="orders" id={o.id} value={o.status} options={["new", "contacted", "fulfilled", "cancelled"]} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {orders.length === 0 && (
          <p className="p-8 text-center font-body text-sm text-ink/50 dark:text-ivory/50">No orders yet.</p>
        )}
      </div>
    </div>
  );
}
