import { createClient } from "@/lib/supabase/server";
import { CategoryManager } from "@/components/admin/CategoryManager";
import type { Category } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function AdminCategoriesPage() {
  const supabase = await createClient();
  const { data } = await supabase.from("categories").select("*").order("type").order("sort_order");
  const categories = (data as Category[]) ?? [];

  return (
    <div>
      <h1 className="mb-6 font-display text-2xl text-maroon dark:text-marigold sm:text-3xl">Categories</h1>
      <CategoryManager categories={categories} />
    </div>
  );
}
