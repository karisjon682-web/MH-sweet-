import Link from "next/link";
import { Package, Tags, ClipboardList, MessageSquare, PlusCircle } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { StatsCard } from "@/components/admin/StatsCard";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  const supabase = await createClient();

  const [{ count: productCount }, { count: categoryCount }, { count: orderCount }, { count: messageCount }] =
    await Promise.all([
      supabase.from("products").select("*", { count: "exact", head: true }),
      supabase.from("categories").select("*", { count: "exact", head: true }),
      supabase.from("orders").select("*", { count: "exact", head: true }).eq("status", "new"),
      supabase.from("contact_messages").select("*", { count: "exact", head: true }).eq("status", "unread"),
    ]);

  return (
    <div>
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl text-maroon dark:text-marigold sm:text-3xl">Dashboard</h1>
          <p className="font-body text-sm text-ink/60 dark:text-ivory/60">Welcome back! Here&apos;s what&apos;s happening.</p>
        </div>
        <Link href="/admin/products/new" className="btn-primary">
          <PlusCircle size={16} /> Add Product
        </Link>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <StatsCard icon={Package} label="Total Products" value={productCount ?? 0} />
        <StatsCard icon={Tags} label="Categories" value={categoryCount ?? 0} />
        <StatsCard icon={ClipboardList} label="New Orders" value={orderCount ?? 0} />
        <StatsCard icon={MessageSquare} label="Unread Messages" value={messageCount ?? 0} />
      </div>

      <div className="mt-8 grid gap-5 sm:grid-cols-3">
        <Link href="/admin/products" className="card-surface flex flex-col gap-2 p-6 hover:shadow-md">
          <Package className="text-maroon dark:text-marigold" size={22} />
          <h3 className="font-display text-lg">Manage Products</h3>
          <p className="font-body text-sm text-ink/60 dark:text-ivory/60">Add, edit, or remove sweets & farsan.</p>
        </Link>
        <Link href="/admin/orders" className="card-surface flex flex-col gap-2 p-6 hover:shadow-md">
          <ClipboardList className="text-maroon dark:text-marigold" size={22} />
          <h3 className="font-display text-lg">View Orders</h3>
          <p className="font-body text-sm text-ink/60 dark:text-ivory/60">See quick-order requests from customers.</p>
        </Link>
        <Link href="/admin/messages" className="card-surface flex flex-col gap-2 p-6 hover:shadow-md">
          <MessageSquare className="text-maroon dark:text-marigold" size={22} />
          <h3 className="font-display text-lg">Customer Messages</h3>
          <p className="font-body text-sm text-ink/60 dark:text-ivory/60">Read and respond to inquiries.</p>
        </Link>
      </div>
    </div>
  );
}
