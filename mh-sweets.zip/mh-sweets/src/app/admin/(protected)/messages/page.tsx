import { createClient } from "@/lib/supabase/server";
import { StatusSelect } from "@/components/admin/StatusSelect";
import type { ContactMessage } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function AdminMessagesPage() {
  const supabase = await createClient();
  const { data } = await supabase.from("contact_messages").select("*").order("created_at", { ascending: false });
  const messages = (data as ContactMessage[]) ?? [];

  return (
    <div>
      <h1 className="mb-6 font-display text-2xl text-maroon dark:text-marigold sm:text-3xl">Customer Messages</h1>

      <div className="flex flex-col gap-4">
        {messages.map((m) => (
          <div key={m.id} className="card-surface flex flex-col gap-3 p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-display text-lg">{m.name}</p>
                <p className="font-body text-xs text-ink/50 dark:text-ivory/50">
                  {m.phone} {m.email ? `• ${m.email}` : ""} • {new Date(m.created_at).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}
                </p>
              </div>
              <StatusSelect table="contact_messages" id={m.id} value={m.status} options={["unread", "read", "replied"]} />
            </div>
            <p className="font-body text-sm text-ink/75 dark:text-ivory/75">{m.message}</p>
          </div>
        ))}
        {messages.length === 0 && (
          <div className="card-surface p-8 text-center font-body text-sm text-ink/50 dark:text-ivory/50">
            No messages yet.
          </div>
        )}
      </div>
    </div>
  );
}
