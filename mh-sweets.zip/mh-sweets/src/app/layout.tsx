import type { Metadata } from "next";
import { Rozha_One, Inter } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/layout/ThemeProvider";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { SHOP } from "@/lib/constants";

const display = Rozha_One({
  subsets: ["latin"],
  weight: "400",
  variable: "--font-display",
  display: "swap",
});

const body = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(SHOP.siteUrl),
  title: {
    default: `${SHOP.name} — ${SHOP.tagline}`,
    template: `%s — ${SHOP.name}`,
  },
  description: SHOP.about,
  keywords: [
    "M H Sweet", "Nakhtrana sweets", "Gujarati sweets", "farsan Nakhtrana",
    "mithai shop", "kaju katli", "penda", "sweets Kutch",
  ],
  openGraph: {
    title: `${SHOP.name} — ${SHOP.tagline}`,
    description: SHOP.about,
    url: SHOP.siteUrl,
    siteName: SHOP.name,
    locale: "en_IN",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: `${SHOP.name} — ${SHOP.tagline}`,
    description: SHOP.about,
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`} suppressHydrationWarning>
      <body className="font-body">
        <ThemeProvider>
          <Navbar />
          <main className="min-h-[70vh]">{children}</main>
          <Footer />
          <WhatsAppButton />
        </ThemeProvider>
      </body>
    </html>
  );
}
