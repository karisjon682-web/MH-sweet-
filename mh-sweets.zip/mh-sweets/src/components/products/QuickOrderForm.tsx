"use client";

import { useState } from "react";
import { Loader2, CheckCircle2 } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { SHOP, waLink } from "@/lib/constants";
import type { Product } from "@/lib/types";
import { formatPrice } from "@/lib/utils";

export function QuickOrderForm({ product }: { product: Product }) {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [form, setForm] = useState({ name: "", phone: "", quantity: 1, note: "" });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("loading");
    const supabase = createClient();
    const { error } = await supabase.from("orders").insert({
      customer_name: form.name,
      phone: form.phone,
      product_id: product.id,
      product_name: product.name,
      quantity: form.quantity,
      unit: product.unit,
      note: form.note,
    });

    if (error) {
      setStatus("error");
      return;
    }
    setStatus("success");

    const message = `Hello ${SHOP.name}! I'd like to order:\n\n*${product.name}* — ${form.quantity} ${product.unit} (${formatPrice(product.price, product.unit)})\nName: ${form.name}\nPhone: ${form.phone}${form.note ? `\nNote: ${form.note}` : ""}`;
    window.open(waLink(message), "_blank");
  }

  return (
    <form onSubmit={handleSubmit} className="card-surface flex flex-col gap-4 p-6">
      <h3 className="font-display text-lg text-maroon dark:text-marigold">Quick Order</h3>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="flex flex-col gap-1.5">
          <label className="font-body text-sm font-medium">Your Name</label>
          <input
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="font-body text-sm font-medium">Phone</label>
          <input
            required
            type="tel"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
          />
        </div>
      </div>
      <div className="flex flex-col gap-1.5">
        <label className="font-body text-sm font-medium">Quantity ({product.unit})</label>
        <input
          required
          type="number"
          min={0.25}
          step={0.25}
          value={form.quantity}
          onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })}
          className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
        />
      </div>
      <div className="flex flex-col gap-1.5">
        <label className="font-body text-sm font-medium">Note (optional)</label>
        <textarea
          rows={2}
          value={form.note}
          onChange={(e) => setForm({ ...form, note: e.target.value })}
          className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
          placeholder="Delivery date, packaging preference, etc."
        />
      </div>

      {status === "error" && (
        <p className="font-body text-sm text-red-600">Something went wrong. Please call us instead.</p>
      )}
      {status === "success" && (
        <p className="flex items-center gap-2 font-body text-sm text-leaf">
          <CheckCircle2 size={16} /> Order request received — continue on WhatsApp to confirm.
        </p>
      )}

      <button type="submit" disabled={status === "loading"} className="btn-whatsapp">
        {status === "loading" && <Loader2 className="animate-spin" size={16} />}
        Order on WhatsApp
      </button>
    </form>
  );
}
