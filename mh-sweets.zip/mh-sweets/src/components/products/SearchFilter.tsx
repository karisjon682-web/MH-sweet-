"use client";

import { Search } from "lucide-react";
import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { useState, useTransition } from "react";
import type { Category, ProductType } from "@/lib/types";
import { cn } from "@/lib/utils";

interface Props {
  categories: Category[];
}

export function SearchFilter({ categories }: Props) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [isPending, startTransition] = useTransition();
  const [query, setQuery] = useState(searchParams.get("q") ?? "");

  const activeType = (searchParams.get("type") as ProductType | null) ?? "sweets";
  const activeCategory = searchParams.get("category") ?? "";

  function updateParams(updates: Record<string, string | null>) {
    const params = new URLSearchParams(searchParams.toString());
    Object.entries(updates).forEach(([key, value]) => {
      if (value) params.set(key, value);
      else params.delete(key);
    });
    startTransition(() => {
      router.push(`${pathname}?${params.toString()}`);
    });
  }

  const visibleCategories = categories.filter((c) => c.type === activeType);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-2">
        {(["sweets", "farsan"] as ProductType[]).map((type) => (
          <button
            key={type}
            onClick={() => updateParams({ type, category: null })}
            className={cn(
              "rounded-full px-5 py-2 font-body text-sm font-semibold capitalize transition-colors",
              activeType === type
                ? "bg-maroon text-ivory dark:bg-marigold dark:text-ink"
                : "bg-maroon/10 text-maroon hover:bg-maroon/20 dark:bg-ivory/10 dark:text-marigold"
            )}
          >
            {type}
          </button>
        ))}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          updateParams({ q: query || null });
        }}
        className="relative"
      >
        <Search
          size={18}
          className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-ink/40 dark:text-ivory/40"
        />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search for penda, kaju katli, sev..."
          className="w-full rounded-full border border-maroon/15 bg-white py-3 pl-11 pr-4 font-body text-sm outline-none focus:border-marigold dark:border-ivory/15 dark:bg-nightsurface"
        />
      </form>

      {visibleCategories.length > 0 && (
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => updateParams({ category: null })}
            className={cn(
              "rounded-full border px-3.5 py-1.5 font-body text-xs font-medium transition-colors",
              !activeCategory
                ? "border-marigold bg-marigold/20 text-marigold-dark dark:text-marigold"
                : "border-maroon/15 text-ink/60 hover:border-marigold dark:border-ivory/15 dark:text-ivory/60"
            )}
          >
            All
          </button>
          {visibleCategories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => updateParams({ category: cat.slug })}
              className={cn(
                "rounded-full border px-3.5 py-1.5 font-body text-xs font-medium transition-colors",
                activeCategory === cat.slug
                  ? "border-marigold bg-marigold/20 text-marigold-dark dark:text-marigold"
                  : "border-maroon/15 text-ink/60 hover:border-marigold dark:border-ivory/15 dark:text-ivory/60"
              )}
            >
              {cat.name}
            </button>
          ))}
        </div>
      )}
      <span aria-hidden className={cn("h-0.5 w-8 rounded-full bg-marigold transition-opacity", isPending ? "opacity-100" : "opacity-0")} />
    </div>
  );
}
