"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { Loader2, UploadCloud } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { slugify } from "@/lib/utils";
import type { Category, Product, ProductType } from "@/lib/types";

interface Props {
  product?: Product;
  categories: Category[];
}

export function ProductForm({ product, categories }: Props) {
  const router = useRouter();
  const isEdit = Boolean(product);

  const [name, setName] = useState(product?.name ?? "");
  const [description, setDescription] = useState(product?.description ?? "");
  const [price, setPrice] = useState(product?.price?.toString() ?? "");
  const [unit, setUnit] = useState(product?.unit ?? "Kg");
  const [type, setType] = useState<ProductType>(product?.type ?? "sweets");
  const [categoryId, setCategoryId] = useState(product?.category_id ?? "");
  const [isAvailable, setIsAvailable] = useState(product?.is_available ?? true);
  const [isFeatured, setIsFeatured] = useState(product?.is_featured ?? false);
  const [imageUrl, setImageUrl] = useState(product?.image_url ?? "");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState(product?.image_url ?? "");
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const filteredCategories = categories.filter((c) => c.type === type);

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const supabase = createClient();

    let finalImageUrl = imageUrl;

    if (imageFile) {
      setUploading(true);
      const ext = imageFile.name.split(".").pop();
      const path = `${slugify(name)}-${Date.now()}.${ext}`;
      const { error: uploadError } = await supabase.storage
        .from("product-images")
        .upload(path, imageFile, { upsert: true });
      setUploading(false);

      if (uploadError) {
        setError(`Image upload failed: ${uploadError.message}`);
        setSaving(false);
        return;
      }
      const { data: publicUrlData } = supabase.storage.from("product-images").getPublicUrl(path);
      finalImageUrl = publicUrlData.publicUrl;
    }

    const payload = {
      name,
      slug: slugify(name),
      description,
      price: Number(price),
      unit,
      type,
      category_id: categoryId || null,
      image_url: finalImageUrl || null,
      is_available: isAvailable,
      is_featured: isFeatured,
    };

    const { error: dbError } = isEdit
      ? await supabase.from("products").update(payload).eq("id", product!.id)
      : await supabase.from("products").insert(payload);

    setSaving(false);

    if (dbError) {
      setError(dbError.message);
      return;
    }

    router.push("/admin/products");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6">
      <div className="grid gap-6 md:grid-cols-[220px_1fr]">
        <div className="flex flex-col gap-2">
          <label className="font-body text-sm font-medium">Product Image</label>
          <div className="relative flex aspect-square w-full items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed border-maroon/20 bg-marigold/5 dark:border-ivory/20">
            {imagePreview ? (
              <Image src={imagePreview} alt="Preview" fill className="object-cover" />
            ) : (
              <UploadCloud className="text-maroon/40 dark:text-ivory/40" size={32} />
            )}
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="absolute inset-0 cursor-pointer opacity-0"
              aria-label="Upload product image"
            />
          </div>
          {uploading && <p className="font-body text-xs text-marigold-dark dark:text-marigold">Uploading image…</p>}
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="flex flex-col gap-1.5 sm:col-span-2">
            <label className="font-body text-sm font-medium">Product Name</label>
            <input
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="font-body text-sm font-medium">Price (₹)</label>
            <input
              required
              type="number"
              min={0}
              step={0.01}
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="font-body text-sm font-medium">Unit</label>
            <select
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
            >
              <option value="Kg">Kg</option>
              <option value="Pkt">Pkt</option>
              <option value="Piece">Piece</option>
              <option value="250g">250g</option>
              <option value="500g">500g</option>
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="font-body text-sm font-medium">Type</label>
            <select
              value={type}
              onChange={(e) => {
                setType(e.target.value as ProductType);
                setCategoryId("");
              }}
              className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
            >
              <option value="sweets">Sweets</option>
              <option value="farsan">Farsan</option>
            </select>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="font-body text-sm font-medium">Category</label>
            <select
              value={categoryId ?? ""}
              onChange={(e) => setCategoryId(e.target.value)}
              className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
            >
              <option value="">Uncategorized</option>
              {filteredCategories.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-1.5 sm:col-span-2">
            <label className="font-body text-sm font-medium">Description (optional)</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
            />
          </div>

          <label className="flex items-center gap-2 font-body text-sm">
            <input type="checkbox" checked={isAvailable} onChange={(e) => setIsAvailable(e.target.checked)} className="h-4 w-4 accent-maroon" />
            Available for order
          </label>
          <label className="flex items-center gap-2 font-body text-sm">
            <input type="checkbox" checked={isFeatured} onChange={(e) => setIsFeatured(e.target.checked)} className="h-4 w-4 accent-maroon" />
            Feature on homepage
          </label>
        </div>
      </div>

      {error && <p className="font-body text-sm text-red-600">{error}</p>}

      <div className="flex items-center gap-3">
        <button type="submit" disabled={saving} className="btn-primary">
          {saving && <Loader2 className="animate-spin" size={16} />}
          {isEdit ? "Save Changes" : "Add Product"}
        </button>
        <button type="button" onClick={() => router.back()} className="btn-secondary">
          Cancel
        </button>
      </div>
    </form>
  );
}
