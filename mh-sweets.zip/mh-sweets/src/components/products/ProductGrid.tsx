import type { Product } from "@/lib/types";
import { ProductCard } from "./ProductCard";

export function ProductGrid({ products }: { products: Product[] }) {
  if (products.length === 0) {
    return (
      <div className="card-surface flex flex-col items-center gap-2 p-12 text-center">
        <p className="font-display text-xl text-maroon dark:text-marigold">No sweets found</p>
        <p className="font-body text-sm text-ink/60 dark:text-ivory/60">
          Try a different search term or category.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
