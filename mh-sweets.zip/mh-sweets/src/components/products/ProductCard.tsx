import Image from "next/image";
import Link from "next/link";
import { Star } from "lucide-react";
import type { Product } from "@/lib/types";
import { formatPrice } from "@/lib/utils";

export function ProductCard({ product }: { product: Product }) {
  return (
    <Link
      href={`/products/${product.slug}`}
      className="card-surface group flex flex-col overflow-hidden transition-transform hover:-translate-y-1 hover:shadow-lg"
    >
      <div className="relative aspect-square w-full overflow-hidden bg-marigold/10">
        {product.image_url ? (
          <Image
            src={product.image_url}
            alt={product.name}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            className="object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center font-display text-3xl text-marigold-dark/40">
            MH
          </div>
        )}
        {product.is_featured && (
          <span className="absolute left-3 top-3 flex items-center gap-1 rounded-full bg-marigold px-2.5 py-1 font-body text-[11px] font-semibold text-ink shadow">
            <Star size={12} fill="currentColor" /> Popular
          </span>
        )}
        {!product.is_available && (
          <span className="absolute inset-0 flex items-center justify-center bg-ink/60 font-body text-sm font-semibold text-ivory">
            Currently Unavailable
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-1 p-4">
        <h3 className="font-display text-lg leading-tight text-ink dark:text-ivory">
          {product.name}
        </h3>
        {product.categories?.name && (
          <span className="font-body text-xs text-ink/50 dark:text-ivory/50">
            {product.categories.name}
          </span>
        )}
        <p className="mt-auto pt-2 font-body text-sm font-semibold text-maroon dark:text-marigold">
          {formatPrice(product.price, product.unit)}
        </p>
      </div>
    </Link>
  );
}
