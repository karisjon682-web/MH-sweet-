"use client";

import { MessageCircle } from "lucide-react";
import { SHOP, waLink } from "@/lib/constants";

export function WhatsAppButton() {
  const message = `Hello ${SHOP.name}! I'd like to know more about your sweets & farsan.`;

  return (
    <a
      href={waLink(message)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Order on WhatsApp"
      className="fixed bottom-5 right-5 z-40 flex items-center gap-2 rounded-full bg-leaf px-5 py-3.5 font-body text-sm font-semibold text-white shadow-lg shadow-leaf/30 transition-transform hover:scale-105 active:scale-95"
    >
      <MessageCircle size={20} />
      <span className="hidden sm:inline">Order on WhatsApp</span>
    </a>
  );
}
