"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LayoutDashboard, Package, Tags, MessageSquare, ClipboardList, LogOut, ExternalLink } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/products", label: "Products", icon: Package },
  { href: "/admin/categories", label: "Categories", icon: Tags },
  { href: "/admin/orders", label: "Orders", icon: ClipboardList },
  { href: "/admin/messages", label: "Messages", icon: MessageSquare },
];

export function AdminSidebar() {
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r border-maroon/10 bg-white p-5 dark:border-ivory/10 dark:bg-nightsurface">
      <div className="mb-8 flex items-center gap-2 px-1">
        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-maroon text-ivory dark:bg-marigold dark:text-ink">
          MH
        </span>
        <span className="font-display text-lg text-maroon dark:text-marigold">M H Sweet</span>
      </div>

      <nav className="flex flex-1 flex-col gap-1">
        {LINKS.map(({ href, label, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className={cn(
              "flex items-center gap-3 rounded-xl px-3 py-2.5 font-body text-sm font-medium text-ink/70 transition-colors hover:bg-maroon/5 dark:text-ivory/70 dark:hover:bg-ivory/10",
              pathname === href && "bg-maroon/10 text-maroon dark:bg-marigold/15 dark:text-marigold"
            )}
          >
            <Icon size={18} /> {label}
          </Link>
        ))}
      </nav>

      <div className="flex flex-col gap-1 border-t border-maroon/10 pt-4 dark:border-ivory/10">
        <Link href="/" target="_blank" className="flex items-center gap-3 rounded-xl px-3 py-2.5 font-body text-sm font-medium text-ink/70 hover:bg-maroon/5 dark:text-ivory/70 dark:hover:bg-ivory/10">
          <ExternalLink size={18} /> View Site
        </Link>
        <button onClick={handleLogout} className="flex items-center gap-3 rounded-xl px-3 py-2.5 font-body text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10">
          <LogOut size={18} /> Sign Out
        </button>
      </div>
    </aside>
  );
}
