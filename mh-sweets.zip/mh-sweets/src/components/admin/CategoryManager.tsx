"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, PlusCircle } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { slugify } from "@/lib/utils";
import { DeleteButton } from "./DeleteButton";
import type { Category, ProductType } from "@/lib/types";

export function CategoryManager({ categories }: { categories: Category[] }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [type, setType] = useState<ProductType>("sweets");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    const supabase = createClient();
    const { error } = await supabase.from("categories").insert({
      name,
      slug: slugify(name),
      type,
      sort_order: categories.filter((c) => c.type === type).length + 1,
    });
    setSaving(false);
    if (error) {
      setError(error.message);
      return;
    }
    setName("");
    router.refresh();
  }

  return (
    <div className="grid gap-8 md:grid-cols-[320px_1fr]">
      <form onSubmit={handleAdd} className="card-surface flex flex-col gap-4 p-6">
        <h2 className="font-display text-lg text-maroon dark:text-marigold">Add Category</h2>
        <div className="flex flex-col gap-1.5">
          <label className="font-body text-sm font-medium">Name</label>
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
            placeholder="e.g. Kaju Item"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="font-body text-sm font-medium">Type</label>
          <select
            value={type}
            onChange={(e) => setType(e.target.value as ProductType)}
            className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
          >
            <option value="sweets">Sweets</option>
            <option value="farsan">Farsan</option>
          </select>
        </div>
        {error && <p className="font-body text-sm text-red-600">{error}</p>}
        <button type="submit" disabled={saving} className="btn-primary">
          {saving ? <Loader2 className="animate-spin" size={16} /> : <PlusCircle size={16} />}
          Add Category
        </button>
      </form>

      <div className="card-surface overflow-x-auto">
        <table className="w-full text-left font-body text-sm">
          <thead className="border-b border-maroon/10 text-xs uppercase tracking-wide text-ink/50 dark:border-ivory/10 dark:text-ivory/50">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Type</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((c) => (
              <tr key={c.id} className="border-b border-maroon/5 last:border-0 dark:border-ivory/5">
                <td className="px-4 py-3 font-medium">{c.name}</td>
                <td className="px-4 py-3 capitalize">{c.type}</td>
                <td className="px-4 py-3">
                  <div className="flex justify-end">
                    <DeleteButton table="categories" id={c.id} confirmLabel={`Delete category "${c.name}"? Products keep their data but lose this category.`} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {categories.length === 0 && (
          <p className="p-8 text-center font-body text-sm text-ink/50 dark:text-ivory/50">No categories yet.</p>
        )}
      </div>
    </div>
  );
}
