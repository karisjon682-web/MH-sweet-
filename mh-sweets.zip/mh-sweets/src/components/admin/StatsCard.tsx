import type { LucideIcon } from "lucide-react";

export function StatsCard({
  icon: Icon,
  label,
  value,
}: {
  icon: LucideIcon;
  label: string;
  value: string | number;
}) {
  return (
    <div className="card-surface flex items-center gap-4 p-5">
      <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-maroon/10 text-maroon dark:bg-marigold/15 dark:text-marigold">
        <Icon size={22} />
      </span>
      <div>
        <p className="font-body text-xs uppercase tracking-wide text-ink/50 dark:text-ivory/50">{label}</p>
        <p className="font-display text-2xl text-ink dark:text-ivory">{value}</p>
      </div>
    </div>
  );
}
