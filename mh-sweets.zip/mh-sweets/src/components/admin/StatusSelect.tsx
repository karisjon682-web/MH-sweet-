"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export function StatusSelect({
  table,
  id,
  value,
  options,
}: {
  table: "orders" | "contact_messages";
  id: string;
  value: string;
  options: string[];
}) {
  const router = useRouter();
  const [current, setCurrent] = useState(value);
  const [saving, setSaving] = useState(false);

  async function handleChange(newStatus: string) {
    setCurrent(newStatus);
    setSaving(true);
    const supabase = createClient();
    await supabase.from(table).update({ status: newStatus }).eq("id", id);
    setSaving(false);
    router.refresh();
  }

  return (
    <select
      value={current}
      disabled={saving}
      onChange={(e) => handleChange(e.target.value)}
      className="rounded-lg border border-maroon/15 bg-transparent px-2.5 py-1.5 font-body text-xs capitalize outline-none focus:border-marigold dark:border-ivory/20"
    >
      {options.map((opt) => (
        <option key={opt} value={opt} className="capitalize">
          {opt}
        </option>
      ))}
    </select>
  );
}
