"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Loader2, CheckCircle2 } from "lucide-react";

export function ContactForm() {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [form, setForm] = useState({ name: "", phone: "", email: "", message: "" });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("loading");
    const supabase = createClient();
    const { error } = await supabase.from("contact_messages").insert({
      name: form.name,
      phone: form.phone,
      email: form.email,
      message: form.message,
    });

    if (error) {
      setStatus("error");
      return;
    }
    setStatus("success");
    setForm({ name: "", phone: "", email: "", message: "" });
  }

  if (status === "success") {
    return (
      <div className="card-surface flex flex-col items-center gap-3 p-8 text-center">
        <CheckCircle2 className="text-leaf" size={40} />
        <h3 className="font-display text-xl text-maroon dark:text-marigold">Message sent!</h3>
        <p className="font-body text-sm text-ink/70 dark:text-ivory/70">
          Thank you for reaching out. We&apos;ll get back to you soon.
        </p>
        <button onClick={() => setStatus("idle")} className="btn-secondary mt-2">
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="card-surface flex flex-col gap-4 p-6 sm:p-8">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="flex flex-col gap-1.5">
          <label htmlFor="name" className="font-body text-sm font-medium">
            Your Name
          </label>
          <input
            id="name"
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
            placeholder="Ramesh Patel"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label htmlFor="phone" className="font-body text-sm font-medium">
            Phone Number
          </label>
          <input
            id="phone"
            required
            type="tel"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
            placeholder="98XXXXXXXX"
          />
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="email" className="font-body text-sm font-medium">
          Email (optional)
        </label>
        <input
          id="email"
          type="email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
          placeholder="you@example.com"
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="message" className="font-body text-sm font-medium">
          Message
        </label>
        <textarea
          id="message"
          required
          rows={4}
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
          className="rounded-xl border border-maroon/15 bg-transparent px-4 py-2.5 font-body text-sm outline-none focus:border-marigold dark:border-ivory/20"
          placeholder="Tell us what you're celebrating..."
        />
      </div>

      {status === "error" && (
        <p className="font-body text-sm text-red-600">
          Something went wrong. Please try again or call us directly.
        </p>
      )}

      <button type="submit" disabled={status === "loading"} className="btn-primary self-start">
        {status === "loading" && <Loader2 className="animate-spin" size={16} />}
        Send Message
      </button>
    </form>
  );
}
