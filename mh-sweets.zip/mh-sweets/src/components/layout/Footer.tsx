import Link from "next/link";
import { MapPin, Phone, Clock } from "lucide-react";
import { SHOP } from "@/lib/constants";

export function Footer() {
  return (
    <footer className="mt-20 border-t border-maroon/10 bg-maroon text-ivory dark:border-ivory/10 dark:bg-nightsurface">
      <div className="container-shop grid gap-10 py-14 md:grid-cols-3">
        <div>
          <h3 className="font-display text-2xl text-marigold">M H Sweet</h3>
          <p className="mt-1 font-body text-xs uppercase tracking-[0.25em] text-marigold/80">
            {SHOP.tagline}
          </p>
          <p className="mt-4 max-w-xs font-body text-sm leading-relaxed text-ivory/75">
            {SHOP.about}
          </p>
        </div>

        <div>
          <h4 className="font-body text-sm font-semibold uppercase tracking-wide text-marigold">
            Our Shops
          </h4>
          <ul className="mt-4 space-y-4">
            {SHOP.locations.map((loc) => (
              <li key={loc.label} className="flex gap-3 font-body text-sm text-ivory/80">
                <MapPin size={18} className="mt-0.5 shrink-0 text-marigold" />
                <span>
                  <strong className="text-ivory">{loc.label}:</strong> {loc.address}
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-body text-sm font-semibold uppercase tracking-wide text-marigold">
            Get in Touch
          </h4>
          <ul className="mt-4 space-y-3 font-body text-sm text-ivory/80">
            <li className="flex items-center gap-3">
              <Phone size={18} className="text-marigold" />
              <a href={`tel:${SHOP.phone.replace(/\s/g, "")}`} className="hover:text-marigold">
                {SHOP.phone}
              </a>
            </li>
            <li className="flex items-center gap-3">
              <Clock size={18} className="text-marigold" />
              Open daily, 9:00 AM – 9:30 PM
            </li>
          </ul>
          <div className="mt-5 flex gap-3">
            <Link href="/products" className="font-body text-sm font-semibold text-marigold underline underline-offset-4">
              Browse Menu
            </Link>
            <Link href="/contact" className="font-body text-sm font-semibold text-marigold underline underline-offset-4">
              Contact Us
            </Link>
          </div>
        </div>
      </div>

      <div className="border-t border-ivory/10 py-5">
        <p className="container-shop font-body text-xs text-ivory/60">
          © {new Date().getFullYear()} M H Sweet, Nakhtrana. All rights reserved.
          <Link href="/admin/login" className="ml-2 text-ivory/40 hover:text-marigold">
            Admin
          </Link>
        </p>
      </div>
    </footer>
  );
}
