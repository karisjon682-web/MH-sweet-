"use client";

import Link from "next/link";
import { useState } from "react";
import { usePathname } from "next/navigation";
import { Menu, X, Phone } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import { SHOP } from "@/lib/constants";
import { cn } from "@/lib/utils";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/products", label: "Sweets" },
  { href: "/products?type=farsan", label: "Farsan" },
  { href: "/contact", label: "Visit & Contact" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  return (
    <header className="sticky top-0 z-50 border-b border-maroon/10 bg-ivory/90 backdrop-blur dark:border-ivory/10 dark:bg-nightmaroon/90">
      <div className="container-shop flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-display text-xl text-maroon dark:text-marigold">
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-maroon text-ivory dark:bg-marigold dark:text-ink">
            MH
          </span>
          <span className="leading-none">
            M H Sweet
            <span className="block font-body text-[10px] font-medium uppercase tracking-[0.25em] text-marigold-dark dark:text-marigold">
              {SHOP.tagline}
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className={cn(
                "font-body text-sm font-medium text-ink/80 transition-colors hover:text-maroon dark:text-ivory/80 dark:hover:text-marigold",
                pathname === link.href && "text-maroon dark:text-marigold"
              )}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <a
            href={`tel:${SHOP.phone.replace(/\s/g, "")}`}
            className="flex items-center gap-2 font-body text-sm font-semibold text-maroon dark:text-marigold"
          >
            <Phone size={16} /> {SHOP.phone}
          </a>
          <ThemeToggle />
        </div>

        <div className="flex items-center gap-2 md:hidden">
          <ThemeToggle />
          <button
            aria-label="Toggle menu"
            onClick={() => setOpen((v) => !v)}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-maroon/15 text-maroon dark:border-ivory/20 dark:text-marigold"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="border-t border-maroon/10 bg-ivory px-4 pb-4 dark:border-ivory/10 dark:bg-nightmaroon md:hidden">
          <div className="flex flex-col gap-1 pt-2">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2 font-body text-sm font-medium text-ink/85 hover:bg-maroon/5 dark:text-ivory/85 dark:hover:bg-ivory/10"
              >
                {link.label}
              </Link>
            ))}
            <a
              href={`tel:${SHOP.phone.replace(/\s/g, "")}`}
              className="mt-2 flex items-center gap-2 rounded-lg px-3 py-2 font-body text-sm font-semibold text-maroon dark:text-marigold"
            >
              <Phone size={16} /> {SHOP.phone}
            </a>
          </div>
        </nav>
      )}
    </header>
  );
}
