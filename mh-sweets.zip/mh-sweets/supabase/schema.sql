-- ============================================================
-- M H Sweets — Supabase Database Schema
-- Run this whole file once in: Supabase Dashboard -> SQL Editor
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------- CATEGORIES ----------
create table if not exists public.categories (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  type text not null check (type in ('sweets', 'farsan')),
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

-- ---------- PRODUCTS ----------
create table if not exists public.products (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  description text default '',
  price numeric(10,2) not null,
  unit text not null default 'Kg',
  type text not null check (type in ('sweets', 'farsan')),
  category_id uuid references public.categories(id) on delete set null,
  image_url text,
  is_available boolean not null default true,
  is_featured boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists products_type_idx on public.products(type);
create index if not exists products_category_idx on public.products(category_id);
create index if not exists products_name_search_idx on public.products using gin (to_tsvector('simple', name));

-- ---------- ORDERS (customer quick-order requests) ----------
create table if not exists public.orders (
  id uuid primary key default uuid_generate_v4(),
  customer_name text not null,
  phone text not null,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity numeric(10,2) not null default 1,
  unit text not null default 'Kg',
  note text default '',
  status text not null default 'new' check (status in ('new', 'contacted', 'fulfilled', 'cancelled')),
  created_at timestamptz not null default now()
);

-- ---------- CONTACT MESSAGES ----------
create table if not exists public.contact_messages (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  phone text not null,
  email text default '',
  message text not null,
  status text not null default 'unread' check (status in ('unread', 'read', 'replied')),
  created_at timestamptz not null default now()
);

-- ---------- updated_at trigger for products ----------
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists products_set_updated_at on public.products;
create trigger products_set_updated_at
before update on public.products
for each row execute function public.set_updated_at();

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.contact_messages enable row level security;

-- Categories: public can read, only authenticated (admin) can write
create policy "categories_public_read" on public.categories for select using (true);
create policy "categories_admin_write" on public.categories for insert with check (auth.role() = 'authenticated');
create policy "categories_admin_update" on public.categories for update using (auth.role() = 'authenticated');
create policy "categories_admin_delete" on public.categories for delete using (auth.role() = 'authenticated');

-- Products: public can read, only authenticated (admin) can write
create policy "products_public_read" on public.products for select using (true);
create policy "products_admin_write" on public.products for insert with check (auth.role() = 'authenticated');
create policy "products_admin_update" on public.products for update using (auth.role() = 'authenticated');
create policy "products_admin_delete" on public.products for delete using (auth.role() = 'authenticated');

-- Orders: anyone can create an order request; only admin can view/manage
create policy "orders_public_insert" on public.orders for insert with check (true);
create policy "orders_admin_select" on public.orders for select using (auth.role() = 'authenticated');
create policy "orders_admin_update" on public.orders for update using (auth.role() = 'authenticated');
create policy "orders_admin_delete" on public.orders for delete using (auth.role() = 'authenticated');

-- Contact messages: anyone can submit; only admin can view/manage
create policy "contact_public_insert" on public.contact_messages for insert with check (true);
create policy "contact_admin_select" on public.contact_messages for select using (auth.role() = 'authenticated');
create policy "contact_admin_update" on public.contact_messages for update using (auth.role() = 'authenticated');
create policy "contact_admin_delete" on public.contact_messages for delete using (auth.role() = 'authenticated');

-- ============================================================
-- STORAGE — product image bucket
-- ============================================================
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

create policy "product_images_public_read"
on storage.objects for select
using (bucket_id = 'product-images');

create policy "product_images_admin_insert"
on storage.objects for insert
with check (bucket_id = 'product-images' and auth.role() = 'authenticated');

create policy "product_images_admin_update"
on storage.objects for update
using (bucket_id = 'product-images' and auth.role() = 'authenticated');

create policy "product_images_admin_delete"
on storage.objects for delete
using (bucket_id = 'product-images' and auth.role() = 'authenticated');

-- ============================================================
-- SEED DATA — Categories
-- ============================================================
insert into public.categories (name, slug, type, sort_order) values
  ('Mava Item', 'mava-item', 'sweets', 1),
  ('Pure Ghee Item', 'pure-ghee-item', 'sweets', 2),
  ('Tel Item', 'tel-item', 'sweets', 3),
  ('Kaju Item', 'kaju-item', 'sweets', 4),
  ('Milk Item', 'milk-item', 'sweets', 5),
  ('Bangali Item', 'bangali-item', 'sweets', 6),
  ('Shrikhand', 'shrikhand', 'sweets', 7),
  ('Farsan', 'farsan', 'farsan', 1)
on conflict (slug) do nothing;

-- ============================================================
-- SEED DATA — Products (full current menu)
-- ============================================================
do $$
declare
  c_mava uuid; c_ghee uuid; c_tel uuid; c_kaju uuid; c_milk uuid; c_bangali uuid; c_shrikhand uuid; c_farsan uuid;
begin
  select id into c_mava from public.categories where slug = 'mava-item';
  select id into c_ghee from public.categories where slug = 'pure-ghee-item';
  select id into c_tel from public.categories where slug = 'tel-item';
  select id into c_kaju from public.categories where slug = 'kaju-item';
  select id into c_milk from public.categories where slug = 'milk-item';
  select id into c_bangali from public.categories where slug = 'bangali-item';
  select id into c_shrikhand from public.categories where slug = 'shrikhand';
  select id into c_farsan from public.categories where slug = 'farsan';

  insert into public.products (name, slug, price, unit, type, category_id, is_featured) values
    -- Mava Item
    ('Penda', 'penda', 400, 'Kg', 'sweets', c_mava, true),
    ('Gulab Pak', 'gulab-pak', 400, 'Kg', 'sweets', c_mava, false),
    ('Gulab Jamun', 'gulab-jamun', 360, 'Kg', 'sweets', c_mava, true),
    ('Topra Pak', 'topra-pak', 460, 'Kg', 'sweets', c_mava, false),
    ('Adadiya', 'adadiya', 600, 'Kg', 'sweets', c_mava, false),
    ('Gundar Pak', 'gundar-pak', 600, 'Kg', 'sweets', c_mava, false),
    ('Dudhi Halvo', 'dudhi-halvo', 480, 'Kg', 'sweets', c_mava, false),
    ('Gor Vara Adadiya', 'gor-vara-adadiya', 640, 'Kg', 'sweets', c_mava, false),
    ('Badam Penda', 'badam-penda', 440, 'Kg', 'sweets', c_mava, false),

    -- Pure Ghee Item
    ('Mohanthar', 'mohanthar', 500, 'Kg', 'sweets', c_ghee, false),
    ('Magdariya Laddu', 'magdariya-laddu', 500, 'Kg', 'sweets', c_ghee, false),
    ('Motichoor Laddu', 'motichoor-laddu', 500, 'Kg', 'sweets', c_ghee, true),
    ('Churmiya Laddu', 'churmiya-laddu', 500, 'Kg', 'sweets', c_ghee, false),
    ('Bundi Na Laddu', 'bundi-na-laddu', 480, 'Kg', 'sweets', c_ghee, false),
    ('Dryfruits Laddu', 'dryfruits-laddu', 520, 'Kg', 'sweets', c_ghee, false),
    ('Desi Ghee Sata', 'desi-ghee-sata', 460, 'Kg', 'sweets', c_ghee, false),
    ('Meshukh', 'meshukh', 600, 'Kg', 'sweets', c_ghee, false),
    ('Khajur Pak', 'khajur-pak', 560, 'Kg', 'sweets', c_ghee, false),
    ('Badami Nilo Halvo', 'badami-nilo-halvo', 480, 'Kg', 'sweets', c_ghee, false),
    ('Suko Halvo', 'suko-halvo', 600, 'Kg', 'sweets', c_ghee, false),

    -- Tel Item
    ('Regular Sata', 'regular-sata', 240, 'Kg', 'sweets', c_tel, false),

    -- Kaju Item
    ('Kaju Katli', 'kaju-katli', 920, 'Kg', 'sweets', c_kaju, true),
    ('Kaju Keshar Roll', 'kaju-keshar-roll', 960, 'Kg', 'sweets', c_kaju, false),
    ('Kaju Pizza', 'kaju-pizza', 980, 'Kg', 'sweets', c_kaju, true),
    ('Kaju Sahi Gulab', 'kaju-sahi-gulab', 1100, 'Kg', 'sweets', c_kaju, false),
    ('Kaju Choco Lava', 'kaju-choco-lava', 1040, 'Kg', 'sweets', c_kaju, false),
    ('Dryfruits Anjir Halvo', 'dryfruits-anjir-halvo', 1100, 'Kg', 'sweets', c_kaju, false),
    ('Kaju Dryfruits Malai', 'kaju-dryfruits-malai', 1040, 'Kg', 'sweets', c_kaju, false),
    ('Rostala', 'rostala', 1100, 'Kg', 'sweets', c_kaju, false),
    ('Kaju Keshar Milk', 'kaju-keshar-milk', 1100, 'Kg', 'sweets', c_kaju, false),
    ('Kaju Biscooof', 'kaju-biscooof', 1200, 'Kg', 'sweets', c_kaju, false),
    ('Biscooof Pizza', 'biscooof-pizza', 1200, 'Kg', 'sweets', c_kaju, false),
    ('Anjir Kasata', 'anjir-kasata', 1100, 'Kg', 'sweets', c_kaju, false),

    -- Milk Item
    ('White Barfi', 'white-barfi', 500, 'Kg', 'sweets', c_milk, false),
    ('Rose Barfi', 'rose-barfi', 500, 'Kg', 'sweets', c_milk, false),
    ('Sekela Penda', 'sekela-penda', 520, 'Kg', 'sweets', c_milk, false),
    ('Milk Cake', 'milk-cake', 520, 'Kg', 'sweets', c_milk, true),
    ('Malai Penda', 'malai-penda', 440, 'Kg', 'sweets', c_milk, false),
    ('Roasted Gulab Pak', 'roasted-gulab-pak', 540, 'Kg', 'sweets', c_milk, false),
    ('Sp. Gulab Pak', 'sp-gulab-pak', 520, 'Kg', 'sweets', c_milk, false),

    -- Bangali Item
    ('Rasgulla', 'rasgulla', 360, 'Kg', 'sweets', c_bangali, true),
    ('Malai Sandwich', 'malai-sandwich', 400, 'Kg', 'sweets', c_bangali, false),
    ('Keshar Kali', 'keshar-kali', 400, 'Kg', 'sweets', c_bangali, false),
    ('Cham Cham', 'cham-cham', 380, 'Kg', 'sweets', c_bangali, false),
    ('Keshar Angur Rabadi', 'keshar-angur-rabadi', 400, 'Kg', 'sweets', c_bangali, false),
    ('Mango Delite', 'mango-delite', 400, 'Kg', 'sweets', c_bangali, false),

    -- Shrikhand
    ('White Shrikhand', 'white-shrikhand', 240, 'Kg', 'sweets', c_shrikhand, false),
    ('Keshar Dryfruits Shrikhand', 'keshar-dryfruits-shrikhand', 380, 'Kg', 'sweets', c_shrikhand, true),

    -- Farsan
    ('Papadi', 'papadi', 280, 'Kg', 'farsan', c_farsan, false),
    ('Sev', 'sev', 260, 'Kg', 'farsan', c_farsan, false),
    ('Bhavnagari Gathiya', 'bhavnagari-gathiya', 260, 'Kg', 'farsan', c_farsan, true),
    ('Champakali Gathiya', 'champakali-gathiya', 260, 'Kg', 'farsan', c_farsan, false),
    ('Lakadiya', 'lakadiya', 260, 'Kg', 'farsan', c_farsan, false),
    ('Jina Lakadiya', 'jina-lakadiya', 260, 'Kg', 'farsan', c_farsan, false),
    ('Alu Sev', 'alu-sev', 300, 'Kg', 'farsan', c_farsan, false),
    ('Masala Papdi', 'masala-papdi', 300, 'Kg', 'farsan', c_farsan, false),
    ('Lasaniya', 'lasaniya', 280, 'Kg', 'farsan', c_farsan, false),
    ('Nailon Sev', 'nailon-sev', 280, 'Kg', 'farsan', c_farsan, false),
    ('Chavanu', 'chavanu', 260, 'Kg', 'farsan', c_farsan, false),
    ('Khatta Mittha', 'khatta-mittha', 260, 'Kg', 'farsan', c_farsan, true),
    ('Banglori', 'banglori', 280, 'Kg', 'farsan', c_farsan, false),
    ('Pauva No Chavdo', 'pauva-no-chavdo', 260, 'Kg', 'farsan', c_farsan, false),
    ('Masala Mamra', 'masala-mamra', 20, 'Pkt', 'farsan', c_farsan, false),
    ('Dryfruits Chavdo (300g)', 'dryfruits-chavdo-300g', 200, 'Pkt', 'farsan', c_farsan, false),
    ('Farali Bataka Chavdo', 'farali-bataka-chavdo', 260, 'Kg', 'farsan', c_farsan, false),
    ('Gajar Chavdo', 'gajar-chavdo', 320, 'Kg', 'farsan', c_farsan, false)
  on conflict (slug) do nothing;
end $$;
